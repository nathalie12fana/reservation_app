import React from 'react'

export const page = () => {
  return (
    <div>page</div>
  )
}
